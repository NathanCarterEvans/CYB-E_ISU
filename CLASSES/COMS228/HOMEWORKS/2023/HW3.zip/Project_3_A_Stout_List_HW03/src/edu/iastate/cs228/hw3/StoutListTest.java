package edu.iastate.cs228.hw3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class StoutListTest {

    private StoutList<String> list;

    @BeforeEach
    public void setUp() {
        list = new StoutList<>();
    }

    @Test
    public void testAddItemSuccessfully() {
        assertTrue(list.add("TestItem"), "Item should be added successfully.");
    }

    @Test
    public void testAddNullItem() {
        assertThrows(NullPointerException.class, () -> {
            list.add(null);
        }, "Adding null should throw NullPointerException.");
    }

    @Test
    public void testAddDuplicateItem() {
        list.add("TestItem");
        assertFalse(list.add("TestItem"), "Duplicate items should not be added.");
    }

    @Test
    public void testRemoveExistingItem() {
        list.add("TestItem");
        assertTrue(list.remove("TestItem"), "Item should be removed successfully.");
    }

    @Test
    public void testRemoveNonExistingItem() {
        assertFalse(list.remove("NonExistingItem"), "Removing non-existing item should return false.");
    }

    @Test
    public void testRemoveFromEmptyList() {
        assertFalse(list.remove("TestItem"), "Removing from an empty list should return false.");
    }

    @Test
    public void testRemoveAtIndex() {
        list.add("TestItem1");
        list.add("TestItem2");
        assertEquals("TestItem2", list.remove(1), "Item at index 1 should be removed.");
    }

    @Test
    public void testRemoveAtInvalidIndex() {
        list.add("TestItem1");
        assertThrows(IndexOutOfBoundsException.class, () -> {
            list.remove(2);
        }, "Removing at an out-of-bounds index should throw IndexOutOfBoundsException.");
    }

    @Test
    public void testSetAtIndex() {
        list.add("TestItem1");
        list.add("OriginalItem");
        assertEquals("OriginalItem", list.set(1, "NewItem"), "The original item should be returned after setting a new value.");
        assertEquals("NewItem", list.get(1), "Item at index 1 should be replaced with the new item.");
    }

    @Test
    public void testSetAtInvalidIndex() {
        assertThrows(IndexOutOfBoundsException.class, () -> {
            list.set(1, "NewItem");
        }, "Setting at an out-of-bounds index should throw IndexOutOfBoundsException.");
    }
}
