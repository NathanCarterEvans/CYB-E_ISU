package edu.iastate.cs228.hw2;
/**
 * @author Nccarter
 */
public class Point implements Comparable<Point> {
    private int x;
    private int y;

    // Static variable to determine if comparison is based on x or y coordinate
    public static boolean compareByX; 

    // Default constructor
    public Point() {
        this.x = 0;
        this.y = 0;
    }

    // Parameterized constructor
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Copy constructor
    public Point(Point p) {
        this.x = p.x;
        this.y = p.y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    // Set the value of the static variable compareByX
    public static void setCompareByX(boolean flag) {
        Point.compareByX = flag;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }

        Point other = (Point) obj;
        return x == other.x && y == other.y;
    }

    @Override
    public int hashCode() {
        return 31 * Integer.hashCode(x) + Integer.hashCode(y);
    }

    @Override
    public int compareTo(Point q) {
        if (compareByX) { 
            int cmp = Integer.compare(this.x, q.x);
            if (cmp != 0) return cmp;
            return Integer.compare(this.y, q.y);
        } else {
            int cmp = Integer.compare(this.y, q.y);
            if (cmp != 0) return cmp;
            return Integer.compare(this.x, q.x);
        }
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
