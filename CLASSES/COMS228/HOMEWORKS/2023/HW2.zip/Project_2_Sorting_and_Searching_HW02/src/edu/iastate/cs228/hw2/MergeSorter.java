package edu.iastate.cs228.hw2;
/**
 * @author Nccarter
 */
public class MergeSorter extends AbstractSorter {

    private Point[] temp;  // Temporary array for the merge process

    public MergeSorter(Point[] pts) {
        super(pts);
        setAlgorithm(Algorithm.MergeSort); // Using setter for better encapsulation
        temp = new Point[pts.length];
    }

    @Override 
    public void sort() {
        mergeSortRec(0, points.length - 1);
    }

    private void mergeSortRec(int low, int high) {
        if (low < high) {
            int mid = (low + high) / 2;

            // Recursively sort the two halves
            mergeSortRec(low, mid);
            mergeSortRec(mid + 1, high);

            // Merge the sorted halves
            merge(low, mid, high);
        }
    }

    private void merge(int low, int mid, int high) {
        for (int i = low; i <= high; i++) {
            temp[i] = points[i];
        }

        int i = low, j = mid + 1, k = low;

        while (i <= mid && j <= high) {
            if (pointComparator.compare(temp[i], temp[j]) <= 0) {
                points[k] = temp[i];
                i++;
            } else {
                points[k] = temp[j];
                j++;
            }
            k++;
        }

        while (i <= mid) {
            points[k] = temp[i];
            k++;
            i++;
        }

        // Since we're merging in the main array, if there are leftover items in the right side, they are already in place and no copying is needed.
    }
}
