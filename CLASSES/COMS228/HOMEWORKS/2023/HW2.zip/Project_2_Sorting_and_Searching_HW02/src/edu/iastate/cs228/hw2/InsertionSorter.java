package edu.iastate.cs228.hw2;

/**
 * This class implements the insertion sort algorithm.
 * 
 * @author Nccarter
 */
public class InsertionSorter extends AbstractSorter {

    /**
     * Constructor takes an array of points. It invokes the superclass constructor, 
     * and sets the instance variables algorithm in the superclass.
     * 
     * @param pts Input array of points
     */
    public InsertionSorter(Point[] pts) {
        super(pts);
        setAlgorithm(Algorithm.InsertionSort); // Using setter for better encapsulation
    }

    /**
     * Perform insertion sort on the array points[].
     */
    @Override
    public void sort() {
        int n = points.length;
        for (int i = 1; i < n; ++i) {
            Point key = points[i];
            int j = i - 1;

            // Move elements of points[0..i-1] that are greater than key
            // to one position ahead of their current position
            while (j >= 0 && points[j].compareTo(key) > 0) {
                points[j + 1] = points[j];
                j = j - 1;
            }
            points[j + 1] = key;
        }
    }
}
