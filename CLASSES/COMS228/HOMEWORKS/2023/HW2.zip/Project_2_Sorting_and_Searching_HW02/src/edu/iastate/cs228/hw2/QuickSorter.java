package edu.iastate.cs228.hw2;
/**
 * @author Nccarter
 */
public class QuickSorter extends AbstractSorter {

    public QuickSorter(Point[] pts) {
        super(pts);
        algorithm = Algorithm.QuickSort; // Assuming Algorithm is an enum in the superclass or accessible scope
    }

    @Override 
    public void sort() {
        quickSort(0, points.length - 1);
    }

    private void quickSort(int first, int last) {
        if (first < last) {
            int pivotIndex = partition(first, last);
            quickSort(first, pivotIndex - 1);
            quickSort(pivotIndex + 1, last);
        }
    }

    private int partition(int first, int last) {
        Point pivot = points[last];
        int i = first;

        for (int j = first; j < last; j++) {
            if (pointComparator.compare(points[j], pivot) <= 0) {
                swap(i, j);
                i++;
            }
        }

        swap(i, last); // Move pivot to its correct position
        return i;
    }

    // A utility function to swap two points in the points[] array
    protected void swap(int i, int j) {
        Point temp = points[i];
        points[i] = points[j];
        points[j] = temp;
    }
}
