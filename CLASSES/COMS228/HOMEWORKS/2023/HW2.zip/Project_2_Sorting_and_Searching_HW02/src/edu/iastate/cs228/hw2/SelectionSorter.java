package edu.iastate.cs228.hw2;

/**
 * This class implements selection sort for an array of Point objects. 
 * 
 * @author Nccarter
 */
public class SelectionSorter extends AbstractSorter
{
    /**
     * Constructor takes an array of points.
     * It invokes the superclass constructor and sets the algorithm type.
     * 
     * @param pts Input array of points.
     */
    public SelectionSorter(Point[] pts)  
    {
        super(pts);
        algorithm = Algorithm.SelectionSort;
        setComparator(0); // Assume 0 corresponds to comparing by x-coordinate
    }    

    /**
     * Apply selection sort on the array points[].
     */
    @Override 
    public void sort()
    {
        int length = points.length;

        for (int i = 0; i < length - 1; i++) 
        {
            int minIndex = i;
            for (int j = i + 1; j < length; j++) 
            {
                if (pointComparator.compare(points[j], points[minIndex]) < 0) 
                {
                    minIndex = j;
                }
            }
            swap(i, minIndex);
        }
    }

    /**
     * Helper method to swap two elements in the array points[].
     * 
     * @param i Index of the first point.
     * @param j Index of the second point.
     */
    protected void swap(int i, int j)
    {
        Point temp = points[i];
        points[i] = points[j];
        points[j] = temp;
    }
}
