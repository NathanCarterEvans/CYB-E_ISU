package edu.iastate.cs228.hw2;

import java.util.Comparator;
/**
 * @author Nccarter
 */
public abstract class AbstractSorter {

    protected Point[] points;
    protected Algorithm algorithm = null;
    protected Comparator<Point> pointComparator = null;

    protected AbstractSorter() {
        // Default constructor
    }

    protected AbstractSorter(Point[] pts) {
        if (pts == null || pts.length == 0) {
            throw new IllegalArgumentException("Input array of points cannot be null or empty.");
        }
        this.points = pts.clone(); // Deep copy to ensure encapsulation
    }

    public void setComparator(int order) {
        if (order < 0 || order > 1) {
            throw new IllegalArgumentException("Order must be either 0 (for x-coordinate) or 1 (for y-coordinate).");
        }
        pointComparator = (order == 0) 
                ? Comparator.comparingInt(Point::getX)
                : Comparator.comparingInt(Point::getY);
    }

    public abstract void sort();

    public Point getMedian() {
        return points[points.length / 2];
    }

    public void getPoints(Point[] pts) {
        System.arraycopy(points, 0, pts, 0, points.length); // Copy points[] to pts[]
    }

    protected void swap(int i, int j) {
        Point temp = points[i];
        points[i] = points[j];
        points[j] = temp;
    }
    
    protected void setAlgorithm(Algorithm algo) {
        this.algorithm = algo;
    }
}
