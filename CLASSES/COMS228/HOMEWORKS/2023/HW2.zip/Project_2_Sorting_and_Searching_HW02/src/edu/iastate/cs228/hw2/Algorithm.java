package edu.iastate.cs228.hw2;

/**
 * 
 * Four sorting algorithms 
 *
 */
public enum Algorithm 
{
	SelectionSort, InsertionSort, MergeSort, QuickSort
}