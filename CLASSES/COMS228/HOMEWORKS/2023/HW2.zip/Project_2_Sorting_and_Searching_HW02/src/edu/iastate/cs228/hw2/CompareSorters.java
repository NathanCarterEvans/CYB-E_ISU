package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
/**
 * @author Nccarter
 */
public class CompareSorters {

    private static final int LOWER_BOUND = -50;
    private static final int RANGE = 100;

    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        System.out.println("Choose an option:\n1. Generate random points\n2. Read points from a file");
        
        int choice = getUserChoice(input);
        
        Point[] points = null;

        switch (choice) {
            case 1:
                System.out.println("Enter the number of random points to generate:");
                int numPts = input.nextInt();
                points = generateRandomPoints(numPts, new Random());
                break;
            case 2:
                // For simplicity, assume readPointsFromFile() exists
                // points = readPointsFromFile();
                break;
        }

        List<PointScanner> scanners = new ArrayList<>();
        scanners.add(new PointScanner(points, Algorithm.SelectionSort));
        scanners.add(new PointScanner(points, Algorithm.InsertionSort));
        scanners.add(new PointScanner(points, Algorithm.MergeSort));
        scanners.add(new PointScanner(points, Algorithm.QuickSort));

        for (PointScanner scanner : scanners) {
            scanner.scan();
            // Assume getScanTime() exists in PointScanner
            // System.out.println(scanner.getAlgorithm() + " took: " + scanner.getScanTime() + " nanoseconds");
        }

        input.close();
    }

    private static int getUserChoice(Scanner input) {
        int choice = 0;
        boolean validChoice = false;

        while (!validChoice) {
            try {
                choice = input.nextInt();
                if (choice == 1 || choice == 2) {
                    validChoice = true;
                } else {
                    System.out.println("Please enter a valid option (1 or 2).");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid option (1 or 2).");
                input.next(); // Clear the invalid input
            }
        }

        return choice;
    }

    public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException {
        if (numPts < 1) {
            throw new IllegalArgumentException("Number of points should be at least 1.");
        }

        Point[] randomPoints = new Point[numPts];
        for (int i = 0; i < numPts; i++) {
            int x = rand.nextInt(RANGE) + LOWER_BOUND;
            int y = rand.nextInt(RANGE) + LOWER_BOUND;
            randomPoints[i] = new Point(x, y);
        }

        return randomPoints;
    }
}
