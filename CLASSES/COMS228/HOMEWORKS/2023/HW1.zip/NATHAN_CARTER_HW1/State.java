package edu.iastate.cs228.hw1;

/**
 * @author edu.iastate.cs228
 * Different type of cell customers and state.
 * Do not modify this file.
 */
public enum State {
	RESELLER, EMPTY, CASUAL, OUTAGE, STREAMER
}

